
"use strict";

const zlib = require("zlib");

// --- lightweight static syntax self-check (counts opening/closing braces at load)
(function syntaxSelfCheck() {
  // This is a minimal shim to help detect truncated pastes in some editors.
  // It does not guarantee correctness, just prints a hint.
  const src = `
    const a = { x: [ (1 + 2) ] };
  `;
  // If this block fails to parse, loader would already throw; so we only log.
  try { new Function(src)(); } catch { console.log("Syntax self-check hint: loader parse error"); }
})();

// Extended VPC Flow Logs field count
const EXPECTED_FIELD_COUNT = 25;

// Optional header (usually remove for Firehose->S3 to save bytes)
const CSV_HEADERS = [
  "version","account-id","interface-id","srcaddr","dstaddr","srcport","dstport",
  "protocol","packets","bytes","start","end","action","log-status","vpc-id",
  "subnet-id","instance-id","tcp-flags","type","pkt-srcaddr","pkt-dstaddr",
  "region","az-id","sublocation-type","sublocation-id"
].join(" ");

// Per-record raw text cap (before gzip)
const PER_RECORD_RAW_CAP_BYTES = 512 * 1024; // 512 KB

// Firehose/Lambda sync hard limit for response payload
const MAX_RESPONSE_BYTES = 6 * 1024 * 1024;

/** Consistent size logging */
function logBytes(label, bytes) {
  const kb = (bytes / 1024).toFixed(2);
  const mb = (bytes / (1024 * 1024)).toFixed(2);
  console.log(`${label}: ${bytes} bytes (${kb} KB, ${mb} MB)`);
}

exports.handler = async (event) => {
  // Batch size
  const batchSizeBytes = Buffer.byteLength(JSON.stringify(event), "utf8");
  logBytes("Incoming Firehose event size", batchSizeBytes);
  console.log(`Incoming record count: ${event.records?.length ?? 0}`);

  const output = [];
  let headerAdded = false; // only once per invocation if you keep headers

  try {
    for (const record of event.records || []) {
      // Input record base64 size
      const inputBase64Bytes = Buffer.byteLength(record.data, "base64");
      logBytes(`Input record ${record.recordId} (base64)`, inputBase64Bytes);

      // Step 1 — decode base64 -> maybe gunzip -> utf8
      let decoded;
      try {
        const raw = Buffer.from(record.data, "base64");
        try {
          decoded = zlib.gunzipSync(raw).toString("utf8");
          console.log(`Record ${record.recordId}: payload was gzipped`);
        } catch {
          decoded = raw.toString("utf8");
          console.log(`Record ${record.recordId}: payload was plain text`);
        }
      } catch (err) {
        console.error(`Record ${record.recordId}: decode failed`, err);
        output.push({ recordId: record.recordId, result: "Dropped" });
        continue;
      }

      // parse wrapper
      let wrapper;
      try {
        wrapper = JSON.parse(decoded);
      } catch (err) {
        console.error(`Record ${record.recordId}: JSON parse failed`, err);
        output.push({ recordId: record.recordId, result: "Dropped" });
        continue;
      }

      // Step 2 — only DATA_MESSAGE
      if (wrapper.messageType !== "DATA_MESSAGE") {
        console.warn(`Record ${record.recordId}: non-DATA_MESSAGE (${wrapper.messageType}), Dropped`);
        output.push({ recordId: record.recordId, result: "Dropped" });
        continue;
      }

      const events = wrapper.logEvents || [];
      if (events.length === 0) {
        console.warn(`Record ${record.recordId}: no logEvents, Dropped`);
        output.push({ recordId: record.recordId, result: "Dropped" });
        continue;
      }

      // Step 3 — build lines with strict byte cap
      const lines = [];
      // Optional header (recommend removing to save bytes)
      if (!headerAdded) {
        lines.push(CSV_HEADERS);
        headerAdded = true;
      }

      let currentBytes = 0;
      for (const le of events) {
        const msg = (le.message || "").trim();
        if (!msg || msg.includes("NODATA")) continue;

        const fields = msg.split(/\s+/);
        if (fields.length !== EXPECTED_FIELD_COUNT) {
          console.warn(`Record ${record.recordId}: dropping malformed line (${fields.length} fields)`);
          continue;
        }

        const line = fields.join(" ");
        const lineBytes = Buffer.byteLength(line, "utf8") + 1; // +1 for newline

        if (currentBytes + lineBytes > PER_RECORD_RAW_CAP_BYTES) {
          console.warn(`Record ${record.recordId}: reached per-record cap (${PER_RECORD_RAW_CAP_BYTES} bytes), truncating`);
          break;
        }

        lines.push(line);
        currentBytes += lineBytes;
      }

      // If only header was added and no valid lines, drop
      const headerOnly = headerAdded ? 1 : 0;
      if (lines.length <= headerOnly) {
        console.warn(`Record ${record.recordId}: no valid lines, Dropped`);
        output.push({ recordId: record.recordId, result: "Dropped" });
        continue;
      }

      // Step 4 — prepare text and ALWAYS gzip
      const text = lines.join("\n") + "\n";
      const textBytes = Buffer.byteLength(text, "utf8");
      logBytes(`Record ${record.recordId} raw transformed text`, textBytes);

      let outBuf;
      try {
        outBuf = zlib.gzipSync(Buffer.from(text, "utf8"));
      } catch (e) {
        console.error(`Record ${record.recordId}: gzip failed`, e);
        output.push({ recordId: record.recordId, result: "ProcessingFailed" });
        continue;
      }

      logBytes(`Record ${record.recordId} gzip buffer`, outBuf.length);
      const outBase64 = outBuf.toString("base64");
      const outBase64Bytes = Buffer.byteLength(outBase64, "utf8");
      logBytes(`Record ${record.recordId} base64(gzip)`, outBase64Bytes);

      // Step 5 — one output per input, preserve recordId
      output.push({
        recordId: record.recordId,
        result: "Ok",
        data: outBase64,
      });
    }

    // Step 6 — final response size check
    const resp = JSON.stringify({ records: output });
    const respBytes = Buffer.byteLength(resp, "utf8");
    logBytes("Final Lambda response JSON", respBytes);

    if (respBytes > MAX_RESPONSE_BYTES) {
      console.error("FINAL RESPONSE EXCEEDS MAX_RESPONSE_BYTES (6 MB hard limit)");

      // Print per-record output sizes for triage
      for (const rec of output) {
        if (rec.data) {
          const bytes = Buffer.byteLength(rec.data, "utf8");
          logBytes(`Output record ${rec.recordId} base64 size`, bytes);
        } else {
          console.log(`Output record ${rec.recordId} has no data (result=${rec.result})`);
        }
      }

      // Also show incoming record sizes (raw base64)
      for (const inRec of event.records || []) {
        const inBytes = Buffer.byteLength(inRec.data, "base64");
        logBytes(`Incoming record ${inRec.recordId} base64 size`, inBytes);
      }

      return {
        records: (event.records || []).map((r) => ({
          recordId: r.recordId,
          result: "ProcessingFailed",
        })),
      };
    }

    return { records: output };
  } catch (err) {
    console.error("FATAL ERROR", err);

    // Diagnostics on fatal error
    const resp = JSON.stringify({ records: output });
    logBytes("Response JSON at fatal error", Buffer.byteLength(resp, "utf8"));

    return {
      records: (event.records || []).map((r) => ({
        recordId: r.recordId,
        result: "ProcessingFailed",
      })),
    };
  }
};
